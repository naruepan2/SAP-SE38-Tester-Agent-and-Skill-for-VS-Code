# SAP ABAP Deep Reverse Engineering V8.7.1

Patch release adding production-ready recursive project-template discovery and reducing runtime context duplication.

## Template setup
Create project folders anywhere below `skills/sap-abap-reverse-engineering/templates/`. Each active template has `template.yaml` and one referenced Markdown file. The Skill recursively scans the templates root, validates paths and metadata, detects duplicate IDs/aliases, builds a compact registry, and loads only the selected template body.

For `FUNCTIONAL_SPEC` or `BOTH`, Preflight offers the recommended valid template, Default, a validated candidate list, AI selection, or a user-specified name. One exact match is selected without asking; ambiguous matches require one guided choice. Source templates are never modified.

## Context-efficiency design
- Agent: safety and orchestration only.
- Skill: compact workflow and on-demand reference router.
- References: one authoritative location per rule.
- Templates: metadata-only scan, selected body loaded once.
- Analysis state: source pointers/fingerprints instead of repeated source.
- Large inventories: sidecars, not main context.
