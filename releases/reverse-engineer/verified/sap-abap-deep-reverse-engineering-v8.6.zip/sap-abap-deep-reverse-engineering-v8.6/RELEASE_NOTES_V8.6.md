# V8.6 - Single-Object Autonomous Bootstrap

## Added
- Best-practice scenario when only one object name is supplied
- Batched intake with no unnecessary package/type/dependency questions
- Root Identity Card and root reconnaissance
- Object-type playbooks and one profile/scope checkpoint
- Evidence-ranked discovery waves and sufficiency-based stopping
- Native-versus-derived complexity metrics
- Static performance finding classes and runtime handoff boundary

## Default scenario
Resolve exact root -> properties/package/source -> CDS Dependency Analyzer/equivalent -> normalize graph -> propose scope/profile -> critical custom paths -> field lineage -> companions -> selective standard foundation -> bounded upstream impact -> gap closure -> selected deliverables.
