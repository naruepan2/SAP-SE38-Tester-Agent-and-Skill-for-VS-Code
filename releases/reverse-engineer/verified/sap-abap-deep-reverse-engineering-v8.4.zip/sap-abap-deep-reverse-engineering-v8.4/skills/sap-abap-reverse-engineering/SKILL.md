---
name: sap-abap-reverse-engineering
description: Read-only SAP ABAP reverse engineering with adaptive tool routing, graph-first CDS discovery, field lineage, and template-based Functional Specifications.
---
# SAP ABAP Reverse Engineering
## Required references
Read in order as applicable:
1. safety-and-preflight.md
2. intake-output-and-scope.md
3. tool-capability-router.md
4. adaptive-root-discovery.md
5. source-acquisition-ladder.md
6. cds-discovery-and-field-lineage.md for CDS paths
7. offline-export-analysis.md for local abapGit/export
8. evidence-coverage-and-completion.md
9. template-and-deliverables.md for FS/BOTH
## State
Maintain scope, frontier, visited canonical nodes, unique edges, structural nodes, retrieval and evidence registries, fingerprints, branch context, field lineage, business rules, configuration, authorization, findings, risks, unresolved items, confirmation queue, coverage, completion status, tool routes, template state, and artifact registry.
## Workflow
### 0 Preflight
Verify system/client/root and each selected connector with a light SAFE_READ. Resolve output mode and analysis profile. Freeze identity.
### 1 Bounded assessment
If profile absent, assess at depth 2 / 25 nodes, recommend Quick 3/75, Standard 5/150, Deep 10/300, or Extended 20/500, explain trade-offs, and wait.
### 2 Scope freeze
Freeze root, objective, audience, downstream lineage, bounded upstream impact, package/system boundaries, budgets, exclusions, and outputs. One scope adjustment; no silent expansion.
### 3 Capability routing and root resolution
Inventory real operations, resolve exact root/type/package/source/fingerprint, choose providers by operation, and persist the discovery plan. Do not require the user to provide package or dependencies when safe tools can resolve them.
### 4 Discovery waves
Wave 0 root source/properties/direct references. Wave 1 direct custom dependencies. Wave 2 calculations, table functions/AMDP, DCL, BDEF, services, UI, configuration. Wave 3 critical-field lineage and branches. Wave 4 bounded package/upstream context. Wave 5 gap closure.
### 5 Reconstruction
Reconstruct business objective, actors, trigger, process, input/output, joins, filters, calculations, fallback, aggregation, currency/unit/date/null semantics, validations, messages, authorization, configuration, service/UI exposure, errors, performance and fan-out risks.
### 6 Evidence closure
Classify claims FACT, DERIVED, INFERRED, or UNVERIFIED. Trace critical outputs to source. Unproven business-owned metadata becomes TBD and enters the confirmation queue.
### 7 Deliverables
Generate only selected outputs. FS/BOTH resolves project template and uses default on missing/invalid template. Do not modify source templates.
### 8 Validation
Reopen files; validate Markdown, Mermaid, links, section/field consistency, evidence IDs, unique denominators, template fingerprint, unresolved/TBD queue, redaction, and source-template immutability. One repair pass.
