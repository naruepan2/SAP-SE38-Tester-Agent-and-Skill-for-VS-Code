---
name: sap-abap-reverse-engineering
description: Read-only SAP reverse engineering with adaptive tool routing, CDS Dependency Analyzer drill-down, field lineage and template-based Functional Specifications.
---
# SAP ABAP Reverse Engineering
## References
Read `guided-interaction-and-human-assistance.md` first for all user-facing questions. Then read as applicable: safety-and-preflight.md; intake-output-and-scope.md; tool-capability-router.md; adaptive-root-discovery.md; source-acquisition-ladder.md; single-object-bootstrap-scenario.md when one seed object is supplied; cds-dependency-analyzer.md; cds-static-performance-analysis.md for CDS complexity/performance interpretation; cds-discovery-and-field-lineage.md; local-repository-export-analysis.md only for an existing export; evidence-coverage-and-completion.md; template-and-deliverables.md for FS/BOTH.
## State
Maintain frozen scope, frontier, canonical nodes, unique edges, structural nodes, retrieval/evidence registries, fingerprints, tool routes, graph metrics, field lineage, rules, configuration, authorization, findings, risks, unresolved items, confirmation queue, coverage, template state, artifacts and completion status.
## Workflow
### 0 Guided collaboration and preflight
Apply the guided interaction rules. Discover before asking; use choice-first but free text whenever safer or more accurate. Batch questions and propose recommended defaults.

### 0.1 Preflight
Verify system/client/root and each connector with light SAFE_READ. Resolve output mode/profile and freeze identity.
### 1 Assessment and scope
If profile absent, assess depth 2/25 nodes, recommend Quick 3/75, Standard 5/150, Deep 10/300 or Extended 20/500, explain and wait. Freeze boundaries, budgets, exclusions and outputs.
### 2 Single-object bootstrap and capability routing
When one seed object is supplied, apply `single-object-bootstrap-scenario.md`.

### 2.1 Capability routing and root resolution
Inventory real operations. Resolve exact root/type/package/source/fingerprint. Persist provider plan and provenance.
### 3 Discovery waves
Wave 0 root properties/source/direct references. For CDS retrieve Dependency Analyzer tree/graph, complexity and used columns when available. Wave 1 normalize graph and read direct custom dependencies. Wave 2 calculations, AMDP, DCL, BDEF, services, UI and configuration. Wave 3 critical-field lineage/branches. Wave 4 bounded package/upstream context. Wave 5 gap closure.
### 4 Reconstruction, static performance interpretation and evidence
For CDS, apply `cds-static-performance-analysis.md`; never equate static complexity with runtime defect.

### 4.1 Reconstruction and evidence
Reconstruct process, inputs/outputs, joins, filters, calculations, fallback, aggregation, currency/unit/date/null behavior, validation, messages, authorization, configuration, exposure, errors, performance and fan-out risks. Classify FACT, DERIVED, INFERRED, UNVERIFIED. Put unproven business metadata in confirmation queue.
### 5 Human assistance, deliverables and validation
Escalate only after autonomous routes are exhausted. Continue with limitations for non-blocking gaps and batch confirmations at delivery.

### 5.1 Deliverables and validation
Generate selected outputs only. Resolve templates for FS/BOTH; use default when missing/invalid; never modify source template. Reopen and validate Markdown, Mermaid, links, consistency, evidence IDs, unique denominators, redaction and template immutability. One repair pass.
