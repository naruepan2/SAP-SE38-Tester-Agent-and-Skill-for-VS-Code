# SAP ABAP Deep Reverse Engineering V8.7

V8.7 adds a guided, peer-to-peer collaboration experience to the V8.6 single-object bootstrap workflow.

## Interaction principles

- Discover technical information before asking.
- Never guess or fabricate missing facts.
- Ask as little as possible.
- Prefer clear choices with brief explanations and a recommended option.
- Use `Other / Specify` or short free text when choices are incomplete or inappropriate.
- Offer `Let AI decide`, `Unknown`, and `Continue with limitation` where useful.
- Batch preflight questions once.
- Ask immediately only for a critical blocker after safe fallbacks are exhausted.
- Never repeat the same unanswered question.

## Normal interaction flow

```text
recommended settings or one batched preflight
-> autonomous root discovery and reconnaissance
-> optional scope/profile checkpoint
-> autonomous deep analysis
-> zero or one targeted critical assistance request
-> one batched confirmation queue
-> selected deliverables
```

## Outputs
`CHAT_SUMMARY`, `FUNCTIONAL_SPEC`, or `BOTH`, with SAP-grounded discovery, CDS Dependency Analyzer support, field lineage, evidence coverage, optional local-export evidence, and explicit runtime limitations.
