# V8.7.1 Architecture

The Agent contains safety and orchestration only. `SKILL.md` routes to references loaded on demand. Detailed rules live once in the relevant reference. Human documentation is not required in runtime context.

Token controls:
- do not preload all references;
- build a metadata-only template registry and load one selected template;
- store source pointers and fingerprints instead of repeating source text;
- keep canonical objects separate from path occurrences;
- summarize tool output before adding it to analysis state;
- move large inventories to sidecars;
- avoid repeating rules across Agent, Skill, README, and references.
