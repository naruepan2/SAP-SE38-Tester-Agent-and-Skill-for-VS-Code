# Single-Object Bootstrap Scenario

## Purpose
Define the default autonomous plan when the user supplies only one SAP repository object name and little or no additional context.

## Trigger
Apply when the request contains a single root object such as `ZC_RTR_ROU_OUTLEASELIABREP` and does not provide package, dependencies, architecture, or supporting artifacts.

## Principle
The object name is a seed, not the scope. Resolve the seed safely, classify its type, establish a small evidence baseline, then expand only through evidence-backed waves. Do not ask the user for information that verified SAFE_READ tools can discover.

## Stage 0 - Batched intake
Request only missing information that cannot be discovered safely:
- system/destination and client when required;
- objective or document intent;
- output mode;
- output language/path for file modes;
- analysis profile, or permission to recommend one;
- project template for FS/BOTH.

Do not ask for package, object type, dependency list, DCL, service, implementation class, or source files before attempting safe discovery.

## Stage 1 - Tool capability map
Inventory actual SAFE_READ capabilities across available connectors. Build an operation map for exact search, properties, package lookup, source, dependency tree/graph, complexity metrics, generated SQL, used columns, where-used, DCL/RAP/service lookup, DDIC metadata, bounded query, and local file access.

Select providers per operation. Verify every selected connector independently. If no live connector works but an existing local export is supplied, switch to `LOCAL_EXPORT_ONLY` and record the limitation.

## Stage 2 - Exact root resolution
Search the exact name first. Resolve aliases only when needed: CDS entity, DDL source, SQL view, database object, service entity, generated object, or local filename.

Create a Root Identity Card:

```yaml
root_identity:
  requested_name: <input>
  canonical_name: <resolved>
  object_type: <type>
  package: <package>
  source_uri: <uri/path>
  active_state: <active/inactive/unknown>
  system: <system>
  client: <client/not_applicable>
  provider: <provider>
  fingerprint: <hash>
  resolution_state: <resolved|ambiguous|not_found>
```

Ask the user only if multiple exact candidates remain materially ambiguous. Never silently substitute a similar object.

## Stage 3 - Root reconnaissance
Read properties and root source. Extract:
- direct repository references;
- exposed fields, parameters, keys and annotations;
- joins, associations, compositions, projections and unions;
- calculations, CASE, CAST, aggregation, currency/unit/date semantics;
- authorization annotation and companion indicators;
- table-function, custom-entity, query-provider, RAP, service and UI indicators;
- static calls, SQL and dynamic-call seeds for non-CDS roots.

Produce a provisional object-type plan and initial risk/unknown list.

## Stage 4 - Type-specific structural discovery

### CDS root
1. Read root source.
2. Acquire ADT SQL Dependency Tree/Graph when a verified equivalent capability exists.
3. Acquire Complexity Metrics, Used Columns and Generated SQL when separately available.
4. Normalize the tree/graph into Canonical Object, Unique Edge, Path Occurrence and Structural Branch registries.
5. Preserve `SELECT`, `UNION`, `UNION ALL` and subqueries as structural context.

### RAP root
Resolve projection/interface CDS, BDEF/BIMP, behavior pool, service definition/binding, metadata extension, DCL, actions, validations, determinations, side effects, feature and authorization methods.

### Program/class/function root
Resolve includes/methods, static calls, SQL access, messages, authorization checks, configuration access, dynamic seeds and bounded where-used impact.

### Service/UI root
Resolve exposed service/manifest entities, backing CDS/RAP model, navigation/actions/value helps, annotations and authorization.

## Stage 5 - Scope proposal and profile checkpoint
After reconnaissance, summarize:
- resolved root/type/package;
- available evidence and connectors;
- estimated unique nodes, path depth and critical branches;
- proposed in-scope companion artifacts;
- exclusions;
- recommended profile and budgets;
- planned outputs.

If the user did not select a profile, stop and request profile approval. After approval, freeze scope. This is the only normal pause after the initial batched intake.

## Stage 6 - Evidence-ranked expansion
Expand in this order:

### Wave A - Critical custom path
Read the root, direct custom dependencies, core calculations, unions, table functions, DCL and directly exposed service/RAP artifacts.

### Wave B - Field lineage
Backward-slice critical output/filter/key fields across every relevant branch. Prioritize amounts, currency/unit, rates, dates, statuses, maturity buckets, reconciliation fields, grouping keys and authorization-relevant fields.

### Wave C - Companion discovery
Use bounded package/context search for sibling DCL, BDEF, service, metadata extension, UI, behavior pool, query provider, configuration helper and AMDP implementation artifacts that SQL dependencies cannot reveal.

### Wave D - Standard foundation
Read standard objects deeply only when they transform a critical field or resolve a business rule. Otherwise inventory them with evidence state and stopping reason.

### Wave E - Bounded upstream impact
Use where-used only for impact candidates relevant to the objective. Keep impact scope separate from downstream lineage.

### Wave F - Gap closure
Close unresolved high-priority fields, branches, security, configuration, table-function, service and evidence conflicts. Do not spend remaining budget on low-value traversal.

## Stage 7 - Static performance interpretation
Separate:
- SAP-native Dependency Tree/Graph/Complexity evidence;
- Agent-derived graph metrics;
- static performance-risk hypotheses;
- runtime performance evidence.

Never convert high static complexity into a confirmed performance defect. Create runtime handoff items for trace, generated SQL execution, execution plan or PlanViz when required.

## Stage 8 - Coverage and stopping
Stop when:
- all critical outputs have source paths or explicit blockers;
- all critical branches are represented;
- critical table functions are resolved to AMDP or blocked;
- DCL/service/RAP companions are covered as applicable;
- no unresolved high-priority static gap remains, or every blocker is documented;
- budget or access limitations are recorded;
- selected deliverables can be produced honestly.

Do not stop merely because depth/node limits were reached. Do not continue merely because budget remains.

## Stage 9 - Deliverables
Generate CHAT_SUMMARY, FUNCTIONAL_SPEC or BOTH from the same frozen state. Include discovery provenance, baseline, metrics source, coverage, conflicts, exclusions, runtime backlog and confirmation queue.
