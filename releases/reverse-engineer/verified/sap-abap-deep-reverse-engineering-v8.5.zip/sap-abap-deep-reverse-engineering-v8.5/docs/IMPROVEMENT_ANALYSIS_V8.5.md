# V8.5 Improvement Analysis
A local export is optional evidence, not an abapGit dependency. For connected CDS analysis, prefer exact root/source, SAP ADT Dependency Analyzer or equivalent graph, canonical normalization, complexity/used-column prioritization, semantic source parsing, critical-field slicing and bounded companion/package discovery.
