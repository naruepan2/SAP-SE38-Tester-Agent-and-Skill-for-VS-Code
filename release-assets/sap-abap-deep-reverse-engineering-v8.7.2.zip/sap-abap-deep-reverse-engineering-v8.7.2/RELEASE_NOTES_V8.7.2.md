# V8.7.2 - Runtime Context Compaction

## Added
- `guided-interaction-core.md`
- `guided-question-patterns.md`
- `runtime-context-management.md`
- `evidence-pointer-contract.md`
- Raw/normalized/active context tiers
- Evidence promotion, wave checkpoints, and safe eviction

## Changed
- Single-object bootstrap is now a compact state machine.
- Skill loads question patterns only when asking and context references only during tool-heavy phases.
- Source and tool output are stored once and reused through evidence pointers.

## Preserved
All V8.7.1 safety, guided UX, single-object discovery, CDS Dependency Analyzer, field lineage, static/runtime separation, optional local evidence, recursive templates, validation, coverage, human assistance, and Functional Specification capabilities.
