# Adaptive Root Discovery
Resolve exact object first. Search aliases only if needed: CDS entity, DDL source, SQL view, service entity, generated object, local filename. Never switch silently to a similar name. Read root metadata/source; record package, parent package, version, activation state, fingerprint, parameters, annotations, direct sources and indicators for DCL/BDEF/service/query provider/table function.
Playbooks:
- CDS: source-first, dependency graph, field lineage, DCL/BDEF/service, bounded package context.
- RAP: projection/interface, BDEF/BIMP, behavior pool, service definition/binding, metadata extension, DCL, UI, actions/validations/determinations.
- Program/class/function: source/includes/methods, static calls/SQL, dynamic seeds, where-used.
- Service/UI: manifest or service model, exposed entities, backing CDS/RAP, navigation/actions/value helps/auth.
Package context follows root resolution and classifies siblings CONFIRMED, CANDIDATE, CONTEXT_ONLY, or EXCLUDED.
