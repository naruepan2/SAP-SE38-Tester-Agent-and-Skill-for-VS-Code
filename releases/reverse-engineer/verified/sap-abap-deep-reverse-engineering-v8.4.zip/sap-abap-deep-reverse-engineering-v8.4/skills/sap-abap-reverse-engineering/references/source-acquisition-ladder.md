# Source Acquisition Ladder
Use the smallest sufficient evidence method:
1 exact object/properties; 2 direct source; 3 structured dependency/where-used; 4 bounded package context; 5 local abapGit/export; 6 repository information-system search; 7 bounded read-only metadata query; 8 unresolved blocker.
Database/table query is fallback only: SAFE_READ, SELECT only, repository/DDIC metadata, confirmed system/client, explicit columns, restrictive predicates, row limit, no confidential output. Never use write statements, procedures, executable reports, or undocumented endpoints. Internal tables vary by release, so prefer semantic repository APIs and source.
