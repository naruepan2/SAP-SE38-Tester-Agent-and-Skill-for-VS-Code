# V8.4 - Adaptive Discovery Planner
Added capability routing for ADT MCP, ABAP FS, ARC-1 and local exports; exact-object/source-first planning; bounded package context; safe source-acquisition fallback; CDS field lineage and fan-out review; offline export reconciliation; and discovery provenance in the FS template.
