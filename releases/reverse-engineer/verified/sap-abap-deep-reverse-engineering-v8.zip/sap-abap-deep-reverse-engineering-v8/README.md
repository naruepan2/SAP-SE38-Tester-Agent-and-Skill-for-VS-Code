# SAP ABAP Deep Reverse Engineering V8

Ready-to-use GitHub Copilot agent and skill package.

## Installation
1. Copy `agents/sap-abap-reverse-engineer.agent.md` to the repository agent location, commonly `.github/agents/`.
2. Copy `skills/sap-abap-reverse-engineering/` to the skill location used by the Copilot environment.
3. Keep the internal `references/` and `templates/` paths unchanged.

## Primary change
After analysis, the workflow now generates a Word-ready Markdown Functional Specification modeled on the supplied project FS structure, while preserving evidence labels, gaps, coverage, CDS discovery metrics, and runtime-test handoff.

## Expected primary output
`<OBJECT>_Functional_Specification.md`

## Important behavior
The package does not invent business-owned metadata, approvals, sign-off, mandatory/optional flags, or expected test results. Unknown values are marked for confirmation.
