---
name: sap-abap-reverse-engineering
description: Read-only SAP reverse engineering with guided interaction, single-object bootstrap, CDS graph/lineage analysis, and recursive project-template selection.
---
# SAP ABAP Reverse Engineering

## Load policy
Load references on demand, not all at once:

- Every interaction: `guided-interaction-and-human-assistance.md`, `safety-and-preflight.md`.
- Intake/scope: `intake-output-and-scope.md`.
- One seed object: `single-object-bootstrap-scenario.md`, then `adaptive-root-discovery.md` and `tool-capability-router.md`.
- Acquisition fallback: `source-acquisition-ladder.md`; local files only when supplied: `local-repository-export-analysis.md`.
- CDS paths: `cds-dependency-analyzer.md`, `cds-discovery-and-field-lineage.md`, and `cds-static-performance-analysis.md` when discussing complexity/performance.
- Evidence/finish: `evidence-coverage-and-completion.md`.
- `FUNCTIONAL_SPEC`/`BOTH`: `template-registry-and-recursive-scan.md`, then `template-and-deliverables.md`; load only the selected Markdown template.

## State
Maintain compact registries for frozen scope, tool routes, canonical nodes, unique edges, path occurrences, structural branches, retrieval/evidence, fingerprints, critical field lineage, findings/risks, unresolved/confirmation items, coverage, interaction decisions, template selection, artifacts, and completion status. Store references to source evidence; do not duplicate full source text in multiple registries.

## Workflow
1. Guided preflight and strict read-only verification.
2. Bounded assessment and one scope/profile checkpoint when needed.
3. Exact root resolution, source reconnaissance, and type-specific discovery.
4. Evidence-ranked expansion and field-level reconstruction.
5. Evidence closure, static/runtime boundary, coverage, and stop decision.
6. Minimal human assistance only for exhausted critical blockers.
7. Selected deliverables, save/reopen validation, and final status.
