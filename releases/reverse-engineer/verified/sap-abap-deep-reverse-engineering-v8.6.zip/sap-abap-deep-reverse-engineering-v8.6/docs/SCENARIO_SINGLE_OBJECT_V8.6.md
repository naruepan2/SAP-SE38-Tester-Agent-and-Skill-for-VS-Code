# Scenario: Only One Object Is Supplied

Input example: `Reverse engineer ZC_RTR_ROU_OUTLEASELIABREP`.

The Agent batches missing system/objective/output questions, discovers actual SAFE_READ capabilities, resolves the exact root/type/package, reads source, retrieves SAP-native CDS dependency artifacts when available, normalizes the graph, and proposes a profile/scope. After one checkpoint, the Agent reads critical custom paths, traces critical fields, resolves AMDP/security/service companions, inventories low-value standard foundations, closes high-priority gaps, and creates selected outputs. Static complexity remains separate from runtime performance.
