# SAP ABAP Deep Reverse Engineering V8.5
Strictly read-only Agent + Skill package for SAP ABAP/CDS/RAP reverse engineering and Functional Specification generation.

## V8.5 rules
- abapGit is not required or invoked. Existing local exports are optional evidence only.
- CDS uses exact root/source, SAP ADT Dependency Analyzer or verified equivalent, canonical graph normalization, complexity/used-column prioritization, field drill-down, companions and bounded context.
- If graph capability is unavailable, source parsing plus repository dependency search builds the graph and the report states the fallback.

## Outputs
CHAT_SUMMARY, FUNCTIONAL_SPEC or BOTH. FS records discovery provenance and optional local baseline.
