# SAP ABAP Deep Reverse Engineering V8.6

V8.6 optimizes the most common starting condition: the user supplies only one SAP object name.

## Best-practice single-object flow

```text
batched intake
-> SAFE_READ capability map
-> exact root/type/package/source/fingerprint
-> root reconnaissance
-> CDS Dependency Analyzer or equivalent, when applicable
-> canonical graph and metrics provenance
-> scope/profile checkpoint
-> critical custom paths
-> critical-field backward slicing
-> AMDP/DCL/BDEF/service/UI/configuration companions
-> selective standard foundation
-> bounded upstream impact
-> evidence gap closure
-> CHAT_SUMMARY / FUNCTIONAL_SPEC / BOTH
```

The Agent does not ask the user for package, object type or dependencies when verified tools can discover them. Full package scans and database metadata queries are fallbacks, not defaults. Existing local exports are optional evidence only; no abapGit operation is invoked.

Static Dependency Analyzer complexity is separated from runtime performance. SAP-native metrics and Agent-derived metrics are labeled separately, and runtime trace/PlanViz remains a handoff.
