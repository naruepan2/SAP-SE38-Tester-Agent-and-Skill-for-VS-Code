# Intake, Output, and Scope
Output modes: CHAT_SUMMARY, FUNCTIONAL_SPEC, BOTH. Analysis depth and delivery format are independent. Ask once when ambiguous. For FS/BOTH ask project template; skip template lookup for Chat. Freeze scope after bounded assessment. Budgets stop tool use but never prove completeness. Late FS conversion reuses valid state after fingerprint verification.
