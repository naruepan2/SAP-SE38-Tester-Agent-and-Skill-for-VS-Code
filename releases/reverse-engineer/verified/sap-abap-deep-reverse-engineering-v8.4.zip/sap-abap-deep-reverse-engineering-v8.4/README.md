# SAP ABAP Deep Reverse Engineering V8.4
V8.4 is a strictly read-only Agent + Skill package for SAP ABAP/CDS/RAP Functional Specification generation. It adds adaptive discovery across ADT MCP, ABAP FS, ARC-1 and local abapGit/export sources.

## Default discovery plan
```text
exact root -> properties/package -> root source -> direct dependencies/fields
-> structured graph -> DCL/BDEF/service/AMDP companions -> critical-field lineage
-> bounded package/upstream context -> gap closure
```
Full package scan is not the default. It is used for package input, unresolved roots, package-wide objectives or dynamic/generated designs. DB metadata lookup is a SELECT-only, restrictive, row-limited fallback.

## Installation
Copy `agents/sap-abap-reverse-engineer.agent.md` and `skills/sap-abap-reverse-engineering/` to the environment while preserving internal paths. `docs/` is human reference.

## Outputs
CHAT_SUMMARY, FUNCTIONAL_SPEC, or BOTH. FS output is `<OBJECT>_Functional_Specification.md` using a selected project template or bundled default.
