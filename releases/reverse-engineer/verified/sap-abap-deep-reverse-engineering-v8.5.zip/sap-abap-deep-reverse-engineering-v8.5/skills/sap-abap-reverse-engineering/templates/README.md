# Templates
Add project templates under `templates/<PROJECT>/`. Selection applies only to FUNCTIONAL_SPEC or BOTH. The bundled default is fallback.
