# {{PROJECT}} Functional Specification
## Document Control
| Attribute | Value |
|---|---|
| Document Origin | Reverse-engineered draft for business confirmation |
| System / Client | {{SYSTEM_CLIENT}} |
| Root Object | `{{ROOT_OBJECT}}` |
| Analysis Baseline | {{BASELINE}} |
| Source Fingerprint | `{{FINGERPRINT}}` |
| Template | {{TEMPLATE_SELECTION}} |
| Completion Status | **{{COMPLETION_STATUS}}** |

> FACT, DERIVED, INFERRED, UNVERIFIED and TBD items must remain distinguishable.

# 1. General Information
{{GENERAL_INFORMATION}}
# 2. Program Overview
{{PROGRAM_OVERVIEW}}
# 3. Application and Exposure
{{APPLICATION_EXPOSURE}}
# 4. Detailed Program Logic
{{DETAILED_LOGIC}}
# 5. Input Parameters and Filters
{{INPUTS_FILTERS}}
# 6. User Actions and Validations
{{ACTIONS_VALIDATIONS}}
# 7. Output and Field Lineage
{{OUTPUT_FIELD_LINEAGE}}
# 8. Configuration
{{CONFIGURATION}}
# 9. Authorizations
{{AUTHORIZATION}}
# 10. Error Handling
{{ERROR_HANDLING}}
# 11. Testing and Runtime Handoff
{{TESTING_HANDOFF}}
# 12. Dependencies and Architecture
{{DEPENDENCIES_ARCHITECTURE}}
## Discovery Method and Provenance
| Item | Result |
|---|---|
| Root-resolution method | {{ROOT_RESOLUTION_METHOD}} |
| Source provider(s) | {{SOURCE_PROVIDERS}} |
| Root package | {{ROOT_PACKAGE}} |
| Discovery strategy | {{DISCOVERY_STRATEGY}} |
| Package scan policy | {{PACKAGE_SCAN_POLICY}} |
| DB metadata fallback | {{DB_FALLBACK_STATUS}} |
| Local export baseline | {{LOCAL_EXPORT_BASELINE}} |
| Source conflicts | {{SOURCE_CONFLICT_STATUS}} |
# 13. Risks, Assumptions, and Limitations
{{RISKS_LIMITATIONS}}
# 14. Evidence and Coverage
{{EVIDENCE_COVERAGE}}
# 15. Confirmation Queue
{{CONFIRMATION_QUEUE}}
