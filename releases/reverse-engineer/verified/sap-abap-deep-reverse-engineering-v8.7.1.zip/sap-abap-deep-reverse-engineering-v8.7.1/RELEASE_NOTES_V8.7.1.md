# V8.7.1 - Recursive Templates and Context Compaction

## Added
- Recursive scan of `templates/` at any depth
- Safe path validation and archive/draft exclusions
- Metadata registry with SHA-256 fingerprints
- Duplicate `template_id`, project/version, and alias detection
- Guided Preflight selection from validated candidates
- Simple and nested project/document/version layouts

## Reduced
- Agent duplicated rules removed; orchestration only
- Skill converted to an on-demand reference router
- Template matching rules consolidated into one reference
- Duplicate human docs replaced by one architecture note
- Full template bodies are no longer loaded during discovery
