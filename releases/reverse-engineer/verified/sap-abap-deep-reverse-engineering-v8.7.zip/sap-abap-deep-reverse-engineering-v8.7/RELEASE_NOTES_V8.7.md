# V8.7 - Guided Collaboration UX

## Added
- Peer-to-peer collaboration style
- Strict no-guessing contract
- Discover-before-asking rule
- Choice-first interaction with free text whenever choices are unsuitable
- Recommended-settings shortcut and progressive disclosure
- `Let AI decide`, `Unknown`, `Other / Specify`, and `Continue with limitation`
- Minimal Human Assistance Gate with autonomous fallback ladder
- Batched confirmations, no-response behavior, and anti-repeat protection
- Interaction-state and assistance provenance in the Functional Specification

## Interaction target
One batched preflight, one optional scope/profile checkpoint, zero or one critical assistance request, and one confirmation queue at delivery.
