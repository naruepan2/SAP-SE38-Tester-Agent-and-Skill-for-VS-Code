# Templates
Add project-specific Markdown templates under `templates/<PROJECT>/` with optional `template.yaml`. Selection applies only to FUNCTIONAL_SPEC or BOTH. Default is used when unspecified, missing or invalid.
