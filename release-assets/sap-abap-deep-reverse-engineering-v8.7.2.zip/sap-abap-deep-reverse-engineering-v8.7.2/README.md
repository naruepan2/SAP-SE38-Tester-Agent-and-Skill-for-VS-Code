# SAP ABAP Deep Reverse Engineering V8.7.2

Patch release for runtime-context and token optimization without capability reduction.

## What changed
- Guided interaction split into a small always-on core and question patterns loaded only when asking.
- Single-object bootstrap condensed to an orchestration state machine that calls existing specialist references.
- Evidence-pointer contract prevents repeated full source/tool output.
- Raw artifacts, normalized evidence, and active context are separated.
- Promotion, wave checkpoints, and safe context eviction keep only current critical evidence active.
- Recursive template discovery and all V8.7.1 capabilities remain unchanged.

## Principle
Keep capability, delay loading, normalize early, reference instead of copy, and evict completed detail without losing traceability.
